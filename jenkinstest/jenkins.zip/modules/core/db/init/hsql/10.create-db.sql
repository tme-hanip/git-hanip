-- begin JENKINSTEST_PRODUCT
create table JENKINSTEST_PRODUCT (
    ID varchar(36) not null,
    VERSION integer not null,
    CREATE_TS timestamp,
    CREATED_BY varchar(50),
    UPDATE_TS timestamp,
    UPDATED_BY varchar(50),
    DELETE_TS timestamp,
    DELETED_BY varchar(50),
    --
    PRODUCTNAME varchar(255),
    --
    primary key (ID)
)^
-- end JENKINSTEST_PRODUCT
